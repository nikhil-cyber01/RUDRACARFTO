RudraCrafto Free Website Demo
===============================

This is a free, static website based on the supplied reference design.

Files:
- index.html
- style.css
- script.js

Features:
- Responsive home page
- Product cards
- Add-to-cart demo
- Photo upload + live preview
- Frame size/color selection
- WhatsApp contact button
- Mobile-friendly layout

Important:
This version is a FRONT-END demo. It does not include a real database, real order management,
real payment processing, or admin login.

To publish for free:
1. Upload these files to a GitHub repository and enable GitHub Pages, OR
2. Drag the folder/ZIP into a static hosting service such as Netlify.

Change your business name, phone number, address and products in index.html/script.js.
